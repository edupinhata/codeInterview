def swapTwoNumbers(array, i, j):
    array[i], array[j] = array[j], array[i]