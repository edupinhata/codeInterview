public class Arrays {
   public static void SwapTwoNumbers(int[] array, int index1, int index2) {
      int tmp = array[index1];
      array[index1] = array[index2];
      array[index2] = tmp;
   }
}
