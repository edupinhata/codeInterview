interface Sorter {
    public int[] Sort(int[] array);
}